﻿using System;

class Recipe
{
    private string[] ingredients;
    private float[] quantities;
    private string[] units;
    private string[] steps;

    public Recipe()
    {
        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        ingredients = new string[numIngredients];
        quantities = new float[numIngredients];
        units = new string[numIngredients];

        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write("Enter the name of ingredient {0}: ", i + 1);
            ingredients[i] = Console.ReadLine();

            Console.Write("Enter the quantity of {0}: ", ingredients[i]);
            quantities[i] = float.Parse(Console.ReadLine());

            Console.Write("Enter the unit of measurement for {0}: ", ingredients[i]);
            units[i] = Console.ReadLine();
        }

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        steps = new string[numSteps];

        for (int i = 0; i < numSteps; i++)
        {
            Console.Write("Enter step {0}: ", i + 1);
            steps[i] = Console.ReadLine();
        }
    }

    public void Display()
    {
        Console.WriteLine("Ingredients:");

        for (int i = 0; i < ingredients.Length; i++)
        {
            Console.WriteLine("{0} {1} {2}", quantities[i], units[i], ingredients[i]);
        }

        Console.WriteLine("Steps:");

        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine("{0}. {1}", i + 1, steps[i]);
        }
    }

    public void Scale(float factor)
    {
        for (int i = 0; i < quantities.Length; i++)
        {
            quantities[i] *= factor;
        }
    }

    public void Reset()
    {
        // Restore the original quantities
        // This assumes that the original quantities are stored in a separate array
        float[] originalQuantities = new float[quantities.Length];
        Array.Copy(quantities, originalQuantities, quantities.Length);
        quantities = originalQuantities;
    }

    public void Clear()
    {
        // Clear all the data by creating new empty arrays
        ingredients = new string[0];
        quantities = new float[0];
        units = new string[0];
        steps = new string[0];
    }
}

class Program
{
    static void Main(string[] args)
    {
        Recipe recipe = new Recipe();

        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("Enter a command:");
            Console.WriteLine("1. Display the recipe");
            Console.WriteLine("2. Scale the recipe");
            Console.WriteLine("3. Reset the quantities");
            Console.WriteLine("4. Clear the recipe");
            Console.WriteLine("5. Exit");

            string input = Console.ReadLine();

            if (input == "1")
            {
                recipe.Display();
            }
            else if (input == "2")
            {
                Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
                float factor = float.Parse(Console.ReadLine());
                recipe.Scale(factor);
            }
            else if (input == "3")
            {
                recipe.Reset();
            }
            else if (input == "4")
            {
                recipe.Clear();
                recipe = new Recipe();
            }
            else if (input == "5")
            {
                break;
            }
            else
            {
                Console.WriteLine("Invalid command.");
            }
        }
    }
}
